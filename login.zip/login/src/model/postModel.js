import  mongoose, { Schema, model, models } from "mongoose";

const postSchema = new Schema({
    message: {
        type: String,
        required: true
    }
}, { timestamps: true });

const preSchema = new Schema({
    name: {
        type: String,
    },
    email: {
        type: String,
    },
    password: {
        type: String,
    }
}, { timestamps: true });

const PostModel = models.post || model('post', postSchema);
const User = models.User || mongoose.model('User', preSchema);

export { PostModel, User };
