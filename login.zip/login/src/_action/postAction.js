"use server"

// import postModel from "../model/postModel"
// import connectDB from "../config/database"
// import { NextResponse } from "next/server"

// export async function getPost (){
//     try {
//         await connectDB()
//        const data = JSON.parse(JSON.stringify(await postModel.find()))
//        return { message: 'GET', data: data };
//     } catch (error) {
//         return {errMsg :error.message}
//     }
// }
