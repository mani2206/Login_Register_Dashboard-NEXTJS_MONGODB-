import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials"
import connectDB from "../../../../config/database"
import { User } from "../../../../model/postModel";
import bcrypt from "bcryptjs"

export const authOptions  = {
    providers: [
        CredentialsProvider({
            name: "credentials",
            credentials: {},

            async authorize(credentials) {
                const { email, password } = credentials
                try {
                    await connectDB()
                    const user = await User.findOne({ email })

                    if (!user) {
                        return null
                    }

                    const passwordMatch = await bcrypt.compare(password, user.password)
                    if (!passwordMatch) {
                        return null
                    }

                    return user;
                } catch (error) {
                    console.log("error:", error);
                    return null; 
                }
            },
        }),
    ],
    session: {
        strategy: "jwt",
    },
    secret: process.env.NEXTAUTH_SECRET,
    pages: {
        signIn: "/"
    }
}

const handler = NextAuth(authOptions)
export default  handler


