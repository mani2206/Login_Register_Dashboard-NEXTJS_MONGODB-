
import { NextResponse } from "next/server";
import connectDB from "../../../config/database"
import bcrypt from "bcryptjs"
import { User } from "../../../model/postModel";
export async function POST(req) {
  try {
    const { name, email, password } = await req.json();
    //  console.log(name,"name");
    //  console.log(email,"name");
    //  console.log(password,"name");
    const hashedPassword = await  bcrypt.hash(password,10)

    await connectDB();
    await User.create({name,email,password:hashedPassword})
    return NextResponse.json({ message: "User registered." }, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { message: "An error occurred while registering the user." },
      { status: 500 }
    );
  }
}